import { View, Text } from 'react-native'
import React from 'react'

export default function addMore() {
  return (
    <View>
      <Text>index</Text>
    </View>
  )
}