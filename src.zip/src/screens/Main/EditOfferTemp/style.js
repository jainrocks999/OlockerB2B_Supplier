import {StyleSheet} from 'react-native';

export default StyleSheet.create({
  img1: {
    height: 20,
    width: 25,
  },
  img2: {
    height: 22,
    width: 26,
    tintColor: '#fff',
  },
});
