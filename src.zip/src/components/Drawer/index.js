// import React, {useState,} from 'react';
// import {
//   View,
 
//   Text
// } from 'react-native';
// import {DrawerContentScrollView} from '@react-navigation/drawer';
// import {useNavigation} from '@react-navigation/native';


// let backPress = 0;
// const DrawerContent = ({props}) => {
//   const navigation = useNavigation();
//   return (
//     <DrawerContentScrollView contentContainerStyle={{}} {...props}>
//       <View style={{flex: 1}}>
//        <Text>
//            {'Logout'}
//        </Text>
        
//       </View>
//     </DrawerContentScrollView>
//   );
// };
// export default DrawerContent;
