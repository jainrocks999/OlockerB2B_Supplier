export default BASEURLS = {
  MainUrl: 'https://olocker.co/api/supplier/',
};
// devappapi.olocker.in  api.myjeweller.in
